using System;
using System.ComponentModel.DataAnnotations;

namespace StudentApi.Models
{
    public class Student
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; } = null!;
        [Required]
        public string Email { get; set; } = null!;
        public int? Age { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
