namespace StudentApi.DTOs
{
    public class CreateStudentRequest
    {
        public string Name { get; set; } = null!;
        public string Email { get; set; } = null!;
        public int? Age { get; set; }
    }

    public class UpdateStudentRequest : CreateStudentRequest { }

    public class StudentDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public string Email { get; set; } = null!;
        public int? Age { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
