using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentApi.Data;
using StudentApi.DTOs;
using StudentApi.Models;

namespace StudentApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StudentsController : ControllerBase
    {
        private readonly AppDbContext _db;
        public StudentsController(AppDbContext db) => _db = db;

        [HttpGet]
        public async Task<IActionResult> GetAll([FromQuery] string? search)
        {
            var q = _db.Students.AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(search))
            {
                var s = search.Trim().ToLower();
                q = q.Where(x => x.Name.ToLower().Contains(s) || x.Email.ToLower().Contains(s));
            }
            var list = await q.OrderByDescending(x => x.CreatedAt)
                              .Select(x => new StudentDto {
                                  Id = x.Id,
                                  Name = x.Name,
                                  Email = x.Email,
                                  Age = x.Age,
                                  CreatedAt = x.CreatedAt
                              }).ToListAsync();

            return Ok(new { success = true, data = list });
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var s = await _db.Students.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
            if (s == null) return NotFound(new { success = false, message = "Student not found" });
            return Ok(new { success = true, data = new StudentDto {
                Id = s.Id, Name = s.Name, Email = s.Email, Age = s.Age, CreatedAt = s.CreatedAt
            }});
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateStudentRequest req)
        {
            if (!ModelState.IsValid) return BadRequest(new { success = false, message = "Validation failed" });

            if (await _db.Students.AnyAsync(x => x.Email.ToLower() == req.Email.ToLower()))
                return BadRequest(new { success = false, message = "Email already exists" });

            var st = new Student { Name = req.Name.Trim(), Email = req.Email.Trim(), Age = req.Age };
            _db.Students.Add(st);
            await _db.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = st.Id }, new { success = true, data = new StudentDto {
                Id = st.Id, Name = st.Name, Email = st.Email, Age = st.Age, CreatedAt = st.CreatedAt
            }});
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateStudentRequest req)
        {
            if (!ModelState.IsValid) return BadRequest(new { success = false, message = "Validation failed" });

            var st = await _db.Students.FirstOrDefaultAsync(x => x.Id == id);
            if (st == null) return NotFound(new { success = false, message = "Student not found" });

            if (await _db.Students.AnyAsync(x => x.Email.ToLower() == req.Email.ToLower() && x.Id != id))
                return BadRequest(new { success = false, message = "Email already exists" });

            st.Name = req.Name.Trim();
            st.Email = req.Email.Trim();
            st.Age = req.Age;
            await _db.SaveChangesAsync();

            return Ok(new { success = true, data = new StudentDto {
                Id = st.Id, Name = st.Name, Email = st.Email, Age = st.Age, CreatedAt = st.CreatedAt
            }});
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var st = await _db.Students.FirstOrDefaultAsync(x => x.Id == id);
            if (st == null) return NotFound(new { success = false, message = "Student not found" });
            _db.Students.Remove(st);
            await _db.SaveChangesAsync();
            return Ok(new { success = true, message = "Student deleted" });
        }
    }
}
