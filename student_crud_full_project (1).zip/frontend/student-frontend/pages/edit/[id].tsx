import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import StudentForm from '../../components/StudentForm';
import api from '../../utils/api';

export default function Edit(){
  const router = useRouter();
  const { id } = router.query;
  const [student, setStudent] = useState<any>(null);

  useEffect(()=>{
    if(!id) return;
    api.get(`/Students/${id}`).then(res=>setStudent(res.data.data)).catch(()=>alert('Failed'));
  },[id]);

  if(!student) return <div style={{padding:20}}>Loading...</div>;
  return (<div style={{padding:20}}><h1>Edit</h1><StudentForm student={student}/></div>);
}
