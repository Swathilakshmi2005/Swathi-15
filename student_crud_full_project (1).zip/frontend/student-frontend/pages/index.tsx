import Link from 'next/link';
import { useEffect, useState } from 'react';
import api from '../utils/api';

export default function Home() {
  const [students, setStudents] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const res = await api.get('/Students');
      setStudents(res.data.data);
    } catch (e) {
      console.error(e);
      alert('Failed to load students');
    } finally { setLoading(false); }
  };

  useEffect(()=>{ load(); }, []);

  const del = async (id:number) => {
    if(!confirm('Delete?')) return;
    await api.delete(`/Students/${id}`);
    load();
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Students</h1>
      <Link href="/create"><button>Add Student</button></Link>
      {loading ? <p>Loading...</p> : (
        <table border={1} cellPadding={8} style={{ marginTop: 12 }}>
          <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Age</th><th>Actions</th></tr></thead>
          <tbody>
            {students.length===0 && <tr><td colSpan={5}>No students</td></tr>}
            {students.map(s=>(
              <tr key={s.id}>
                <td>{s.id}</td>
                <td>{s.name}</td>
                <td>{s.email}</td>
                <td>{s.age ?? '-'}</td>
                <td>
                  <Link href={`/edit/${s.id}`}><button>Edit</button></Link>
                  <button onClick={()=>del(s.id)} style={{ marginLeft: 8 }}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
