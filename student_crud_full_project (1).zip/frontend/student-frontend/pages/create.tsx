import StudentForm from '../components/StudentForm';
export default function Create(){ return (<div style={{padding:20}}><h1>Create</h1><StudentForm/></div>); }
