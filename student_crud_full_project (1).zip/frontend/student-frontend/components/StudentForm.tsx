import { useState } from 'react';
import { useRouter } from 'next/router';
import api from '../utils/api';

export default function StudentForm({ student }: any) {
  const router = useRouter();
  const [form, setForm] = useState({ name: student?.name || '', email: student?.email || '', age: student?.age || '' });

  const handle = (e: any) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e: any) => {
    e.preventDefault();
    try {
      if (student) {
        await api.put(`/Students/${student.id}`, form);
      } else {
        await api.post('/Students', form);
      }
      router.push('/');
    } catch (err: any) {
      alert(err?.response?.data?.message || 'Failed');
    }
  };

  return (
    <form onSubmit={submit} style={{ display: 'grid', gap: 8, maxWidth: 480 }}>
      <input name="name" placeholder="Name" value={form.name} onChange={handle} required />
      <input name="email" placeholder="Email" value={form.email} onChange={handle} required />
      <input name="age" placeholder="Age" value={form.age} onChange={handle} />
      <button type="submit">{student ? 'Update' : 'Create'}</button>
    </form>
  );
}
